package com.chigeai00.customizedrental;

import android.app.Application;
import android.content.Context;

public class MyApplication extends Application {


}
