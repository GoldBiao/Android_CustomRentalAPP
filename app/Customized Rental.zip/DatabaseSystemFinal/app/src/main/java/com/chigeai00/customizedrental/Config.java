package com.chigeai00.customizedrental;

import android.content.Context;

public class Config {
    public static Context CONTEXT;
}
